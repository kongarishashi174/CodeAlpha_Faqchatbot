# FAQ Chatbot

A simple FAQ chatbot that answers questions by matching them to a stored list of FAQs using NLP.
Built with Python (Flask), NLTK, and scikit-learn, with a plain HTML/CSS/JavaScript frontend.

## Features
- Chat interface where users type questions
- NLP preprocessing with NLTK (tokenizing, stop-word removal, lemmatization)
- FAQ matching with TF-IDF and cosine similarity
- Automatic answers with the matched question and a confidence score
- Fallback reply asking the user to rephrase, with "Did you mean" suggestions
- Clickable suggested questions and FAQ categories
- Responsive layout for phones and desktops

## How it works
1. Each FAQ (question + answer) in `faqs.json` is cleaned and converted to a TF-IDF vector.
2. The user's question goes through the same cleaning and vectorizing.
3. Cosine similarity finds the closest FAQ.
4. If the score is above the threshold (default `0.22`), its answer is returned. Otherwise the bot asks the user to rephrase.

## Project structure
```
faq-chatbot/
├── app.py            # Flask server and API routes
├── chatbot.py        # Preprocessing + TF-IDF + cosine similarity
├── faqs.json         # FAQ data (edit this)
├── requirements.txt
└── static/
    ├── index.html
    ├── style.css
    └── script.js
```

## Getting started
```bash
git clone https://github.com/<your-username>/faq-chatbot.git
cd faq-chatbot
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser. The first run downloads small NLTK data files, so internet is needed once.

## Customising
- **Your own FAQs:** edit `faqs.json` (fields: `category`, `question`, `answer`).
- **Strictness:** change `threshold` in `FAQBot(...)` in `chatbot.py`.
- **Everyday wording:** add entries to `SYNONYMS` in `chatbot.py`.

## API
| Method | Route | Description |
|--------|-------|-------------|
| GET | `/api/faqs?category=` | Categories and suggested questions |
| POST | `/api/ask` | Body `{"question": "..."}`; returns the answer or a fallback |

## License
MIT
