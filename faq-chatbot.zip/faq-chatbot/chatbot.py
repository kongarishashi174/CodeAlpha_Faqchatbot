"""FAQ matching engine: NLTK preprocessing + TF-IDF + cosine similarity."""
import json
import re
from pathlib import Path

import nltk
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import RegexpTokenizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Download required NLTK data once (silently skipped if already present).
for path, pkg in (("corpora/stopwords", "stopwords"), ("corpora/wordnet", "wordnet")):
    try:
        nltk.data.find(path)
    except LookupError:
        try:  # only download when missing; failures are tolerated (fallbacks below)
            nltk.download(pkg, quiet=True)
        except Exception:
            pass

try:
    from nltk.corpus import stopwords
    STOP_WORDS = set(stopwords.words("english"))
except Exception:  # offline fallback
    from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
    STOP_WORDS = set(ENGLISH_STOP_WORDS)

# Keep words that carry meaning in questions like "how do I ..." / "can I not ..."
STOP_WORDS -= {"not", "no"}

# Small synonym map so everyday wording maps onto the FAQ vocabulary.
SYNONYMS = {
    "safe": "secure", "safety": "secure", "security": "secure", "protected": "secure",
    "android": "mobile", "ios": "mobile", "iphone": "mobile", "phone": "mobile", "app": "app",
    "2fa": "two factor authentication", "mfa": "two factor authentication",
    "options": "methods", "option": "method", "pay": "payment", "paying": "payment",
    "card": "payment", "money": "refund",
    "login": "password", "signin": "password", "forgot": "reset", "change": "update",
    "help": "support", "contact": "support", "reach": "support",
    "price": "payment", "cost": "payment", "bill": "invoice", "receipt": "invoice",
    "cancel": "delete", "close": "delete",
}
GREETINGS = {"hi", "hello", "hey", "hii", "good morning", "good evening", "good afternoon"}

_tokenizer = RegexpTokenizer(r"[a-z0-9]+")
_lemmatizer = WordNetLemmatizer()


def _lemma(word: str) -> str:
    try:
        return _lemmatizer.lemmatize(_lemmatizer.lemmatize(word, "v"), "n")
    except LookupError:  # wordnet unavailable
        return word


def preprocess(text: str) -> str:
    """Lowercase -> tokenize -> remove stop words -> lemmatize."""
    tokens = _tokenizer.tokenize(text.lower())
    tokens = [w for t in tokens for w in SYNONYMS.get(t, t).split()]
    tokens = [_lemma(t) for t in tokens if t not in STOP_WORDS]
    return " ".join(tokens)


class FAQBot:
    def __init__(self, faq_path="faqs.json", threshold=0.22, suggest_threshold=0.10):
        self.faqs = json.loads(Path(faq_path).read_text(encoding="utf-8"))
        self.threshold = threshold
        self.suggest_threshold = suggest_threshold
        # Match against question text (weighted by repeating it) plus the answer.
        corpus = [preprocess(f"{f['question']} {f['question']} {f['answer']}") for f in self.faqs]
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True)
        self.matrix = self.vectorizer.fit_transform(corpus)

    def ask(self, user_question: str) -> dict:
        if user_question.lower().strip(" !.?") in GREETINGS:
            return {"found": True, "greeting": True, "confidence": 1.0,
                    "answer": "Hello! Ask me anything about our services, billing, your account or the mobile app."}
        cleaned = preprocess(user_question)
        if not cleaned:
            return self._fallback([])

        scores = cosine_similarity(self.vectorizer.transform([cleaned]), self.matrix)[0]
        ranked = scores.argsort()[::-1]
        best = ranked[0]

        if scores[best] >= self.threshold:
            return {
                "found": True,
                "answer": self.faqs[best]["answer"],
                "matched_question": self.faqs[best]["question"],
                "confidence": round(float(scores[best]), 2),
                "category": self.faqs[best]["category"],
            }
        close = [self.faqs[i]["question"] for i in ranked[:3] if scores[i] >= self.suggest_threshold]
        return self._fallback(close)

    @staticmethod
    def _fallback(suggestions):
        return {
            "found": False,
            "answer": "Sorry, I couldn't find a good answer to that. Could you rephrase your question using different words?",
            "suggestions": suggestions,
        }

    def questions(self, category=None):
        return [f["question"] for f in self.faqs if category in (None, "", f["category"])]

    def categories(self):
        return list(dict.fromkeys(f["category"] for f in self.faqs))
