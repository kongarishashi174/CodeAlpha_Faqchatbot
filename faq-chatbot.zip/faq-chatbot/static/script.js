const $ = (id) => document.getElementById(id);
const messages = $("messages"), input = $("input"), typing = $("typing");
const BOT_ICON = '<svg viewBox="0 0 24 24"><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M12 8V4M9 13h.01M15 13h.01M9 17h6"/></svg>';
const USER_ICON = '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg>';
let category = "";

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}
const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function addMessage(role, text, extra) {
  const row = el("div", "msg " + role);
  row.appendChild(el("div", "avatar", role === "bot" ? BOT_ICON : USER_ICON));
  const bubble = el("div", "bubble");
  bubble.appendChild(el("div", "", esc(text)));
  if (extra) extra(bubble);
  row.appendChild(bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
}

function chips(list, container) {
  list.forEach((q) => {
    const b = el("button", "chip", esc(q));
    b.type = "button";
    b.onclick = () => send(q);
    container.appendChild(b);
  });
}

function botExtras(data) {
  return (bubble) => {
    if (data.found && data.matched_question) {
      bubble.appendChild(el("div", "meta", "Matched: " + esc(data.matched_question) + " (" + Math.round(data.confidence * 100) + "% match)"));
    }
    if (!data.found && data.suggestions && data.suggestions.length) {
      bubble.appendChild(el("div", "meta", "Did you mean:"));
      const c = el("div", "chips");
      chips(data.suggestions, c);
      bubble.appendChild(c);
    }
    if (data.found && !data.greeting) {
      const fb = el("div", "fb", '<button type="button">Helpful</button><button type="button">Not helpful</button>');
      fb.querySelectorAll("button").forEach((b) => (b.onclick = () => {
        fb.querySelectorAll("button").forEach((x) => x.classList.remove("on"));
        b.classList.add("on");
      }));
      bubble.appendChild(fb);
    }
  };
}

async function send(text) {
  text = text.trim();
  if (!text) return;
  addMessage("user", text);
  input.value = "";
  typing.hidden = false;
  try {
    const [res] = await Promise.all([
      fetch("/api/ask", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: text }) }),
      new Promise((r) => setTimeout(r, 500)),
    ]);
    const data = await res.json();
    typing.hidden = true;
    addMessage("bot", data.answer || data.error, botExtras(data));
  } catch {
    typing.hidden = true;
    addMessage("bot", "I couldn't reach the server. Please check your connection and try again.");
  }
}

async function loadFaqs(cat = "") {
  const r = await fetch("/api/faqs" + (cat ? "?category=" + encodeURIComponent(cat) : ""));
  return r.json();
}

async function showSuggestions() {
  const { questions } = await loadFaqs(category);
  const box = $("suggestions");
  box.innerHTML = "";
  chips(questions.slice(0, 4), box);
}

async function init() {
  const { categories } = await loadFaqs();
  const nav = $("categories");
  ["", ...categories].forEach((c) => {
    const b = el("button", "cat" + (c === "" ? " active" : ""), esc(c || "All questions"));
    b.type = "button";
    b.onclick = () => {
      category = c;
      nav.querySelectorAll(".cat").forEach((x) => x.classList.remove("active"));
      b.classList.add("active");
      showSuggestions();
      $("sidebar").classList.remove("open");
    };
    nav.appendChild(b);
  });
  showSuggestions();
  addMessage("bot", "Hi! I can answer common questions about our product. What would you like to know?");
}

$("form").addEventListener("submit", (e) => { e.preventDefault(); send(input.value); });
$("menuBtn").onclick = () => $("sidebar").classList.toggle("open");
init();
