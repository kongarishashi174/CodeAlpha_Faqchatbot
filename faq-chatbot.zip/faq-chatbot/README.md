# FAQ Chatbot

Flask + NLTK + TF-IDF/cosine similarity. Frontend is plain HTML/CSS/JS.

## Run
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Files
- `faqs.json` – FAQ storage (category, question, answer). Add your own entries here.
- `chatbot.py` – preprocessing (tokenize, stop words, lemmatize), TF-IDF vectors, cosine similarity, fallback.
- `app.py` – Flask routes: `GET /api/faqs`, `POST /api/ask`.
- `static/` – chat UI (responsive; sidebar becomes a menu on phones).

## Tuning
In `chatbot.py`, `FAQBot(threshold=0.22)`: raise it for stricter matches, lower it for more lenient ones.
Add everyday wording to `SYNONYMS` so users' phrasing maps to your FAQ vocabulary.
