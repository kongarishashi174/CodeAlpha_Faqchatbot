from flask import Flask, jsonify, request, send_from_directory

from chatbot import FAQBot

app = Flask(__name__, static_folder="static", static_url_path="/static")
bot = FAQBot("faqs.json")


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/api/faqs")
def faqs():
    return jsonify(categories=bot.categories(),
                   questions=bot.questions(request.args.get("category")))


@app.post("/api/ask")
def ask():
    text = (request.get_json(silent=True) or {}).get("question", "").strip()
    if not text:
        return jsonify(error="Please type a question."), 400
    return jsonify(bot.ask(text[:500]))


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
